# Shared Living World — complete build handoff, v2.0

**Product decisions:** `person / creative / fast / constrained / radical / event / harsh`.

This folder is a **game-design + implementation specification**, not a functioning game or executable game engine. It is intended to be placed at the root of a new repository and given to a coding agent.

Read in order:

1. [PRODUCT_SPEC.md](PRODUCT_SPEC.md): player experience and first complete release.
2. [DECISIONS_AND_CONFLICTS.md](DECISIONS_AND_CONFLICTS.md): choices, implications and resolved contradictions.
3. [ARCHITECTURE.md](ARCHITECTURE.md): world state, cognition, processes/institutions, LLM protocol, event ending and persistence.
4. [CODING_SPEC.md](CODING_SPEC.md): packages, development phases, automated acceptance and delivery definition.
5. [AGENTS.md](AGENTS.md): coding-agent instructions.
6. [START_WITH_CODEX.md](START_WITH_CODEX.md): primary handoff prompt.

## What changed since the previous pack

- Person-first and individual causal life timelines replace global-strategy-first framing.
- Fast shared simulation gets independent private catch-up/life replay; no slowing or pausing shared world.
- Constrained character creation but radical *future* personality development, with causal memory and goal transitions.
- Harsh world: no protagonist immunity, no artificially enforced cruelty; public narrations still have moderation and privacy limits.
- Event-driven ending replaces mandatory fixed-length season; max horizon is clearly an administrative archive safeguard.
- LLM creativity gets durable **Actions + Processes + Institutions + Agent Policies**, not only one-time Effect patches.
- Two distinct historical stores: full State Journal for lossless recovery, salient Event Ledger for human history, plus read-only narrative projections.
- Full release milestones plus agent-executed tests replace repeated user-facing demos.

## Startup intent

Create a repository, copy all files there, give your agent the text of `START_WITH_CODEX.md`, and let it execute the implementation path. LLM provider credentials and production hosting are optional external setup; the coding agent must not pretend those resources exist if they haven't been provided.
